# Keyboards (roadmap)

The CLI already converts Roman key text to Gupt glyphs (`gupt enc`, `gupt repl`).
Planned input methods, all using the same Roman key rules and the codepoints in CODEPOINTS.md:

- **Keyman** keyboard (Android, iOS, Windows, macOS, Linux, web) with transliteration and a touch
  layout that mirrors the consonant map.
- **ibus-m17n / XKB** layout for Kali Linux desktops.
- **Termux:** use `gupt repl`, or `gupt enc` in shell pipelines.

Contributions welcome.
