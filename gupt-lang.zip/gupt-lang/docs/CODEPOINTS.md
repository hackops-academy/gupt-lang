# Gupt codepoints

All glyphs live in the Unicode Private Use Area.

| Codepoint | Roman key | Meaning |
|---|---|---|
| U+E000 | a | vowel plain |
| U+E001 | e | vowel plain |
| U+E002 | i | vowel plain |
| U+E003 | o | vowel plain |
| U+E004 | u | vowel plain |
| U+E005 | p | lip plain |
| U+E006 | b | lip voiced |
| U+E007 | m | lip nasal |
| U+E008 | f | lip hiss |
| U+E009 | v | lip buzz |
| U+E00A | w | lip glide |
| U+E00B | t | tee plain |
| U+E00C | d | tee voiced |
| U+E00D | n | tee nasal |
| U+E00E | s | tee hiss |
| U+E00F | z | tee buzz |
| U+E010 | l | tee glide |
| U+E011 | r | tee trill |
| U+E012 | T | ret plain |
| U+E013 | D | ret voiced |
| U+E014 | N | ret nasal |
| U+E015 | c | pal plain |
| U+E016 | j | pal voiced |
| U+E017 | ñ | pal nasal |
| U+E018 | sh | pal hiss |
| U+E019 | y | pal glide |
| U+E01A | k | thr plain |
| U+E01B | g | thr voiced |
| U+E01C | G | thr nasal |
| U+E01D | h | thr hiss |
| U+E020 | aa | long vowel |
| U+E021 | ee | long vowel |
| U+E022 | ii | long vowel |
| U+E023 | oo | long vowel |
| U+E024 | uu | long vowel |
| U+E030 | ph | breath ring |
| U+E031 | bh | breath ring |
| U+E032 | th | breath ring |
| U+E033 | dh | breath ring |
| U+E034 | Th | breath ring |
| U+E035 | Dh | breath ring |
| U+E036 | ch | breath ring |
| U+E037 | jh | breath ring |
| U+E038 | kh | breath ring |
| U+E039 | gh | breath ring |
| U+E050 | . | sentence dot |

Chemistry letters: U+E100..U+E11D (lowercase, double headline) and U+E140..U+E15D (capital, double headline + flag), in the same order as the 30 base glyphs.
