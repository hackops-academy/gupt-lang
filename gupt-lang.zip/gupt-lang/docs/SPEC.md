# Gupt language specification (v0.1)

## Script
Thirty glyphs: five vowels and 25 consonants. Consonants are built from a **place** shape and a
**manner** mark.

| Place | Shape | Letters |
|---|---|---|
| Lips | ring | p b m f v w |
| Teeth | triangle | t d n s z l r |
| Curl | upside-down triangle | T D N |
| Roof | arch | c j ñ x(sh) y |
| Throat | stem | k g G(ng) h |

Manner marks: none (plain), dot (voiced), underline (nasal), bar (hiss), bar + dot (buzz),
two dots (glide), zigzag (trill). A small ring above a stop (p b t d T D c j k g) adds a breath
puff (ph bh th dh Th Dh ch jh kh gh). A long bar under a vowel doubles its length.

Vowels: a = dot, e = flat dash, i = tall dash, o = small ring, u = cup.

## Roman key (input format)
`sh` is one glyph. A doubled vowel is long. A stop followed by `h` takes the ring.
A hyphen separates morphemes and blocks digraphs (`k-h` is k then h). Chemistry goes in `[[ ]]`.

## Grammar
1. Order is Subject, Object, Verb.
2. Particles: `ve` marks the doer, `to` the object, `ne` a place.
3. No verb "to be": `mi ve chatra` = I am a student.
4. Tense suffixes: present = stem, past `-ak`, future `-ul`.
5. Plural: `-i` after a consonant, `-ni` after a vowel; none after a number word.
6. `na` before the verb negates. `ka` at the end asks a question.
7. Adjectives come before the noun and never change.
8. `ar` means "and".

## Chemistry mode
Double headline. Symbols are spelled letter by letter with the matching glyph; capitals carry a
flag, so `Co` (one flag) differs from `CO` (two flags). `X` is written k+s and `Q` as k.
Digits stay ordinary digits.

See CODEPOINTS.md for the Unicode mapping.
