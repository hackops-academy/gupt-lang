import random
from engine import *
from reportlab.lib.pagesizes import A5
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table,
                                TableStyle, PageBreak, NextPageTemplate, KeepTogether, CondPageBreak)

W, H = A5
M = 34
NAVY = colors.HexColor('#12152e')
TINT = colors.HexColor('#eef1f8')
OUT = 'Gupt_Learning_Book.pdf'

body = ParagraphStyle('body', fontName='DV', fontSize=8.6, leading=12.6, textColor=INK, spaceAfter=5)
h1 = ParagraphStyle('h1', fontName='DV-B', fontSize=15, leading=19, textColor=INK, spaceBefore=4, spaceAfter=6)
h2 = ParagraphStyle('h2', fontName='DV-B', fontSize=10.5, leading=14, textColor=TEAL, spaceBefore=9, spaceAfter=4)
small = ParagraphStyle('small', fontName='DV', fontSize=7.3, leading=10, textColor=GREY)
cell = ParagraphStyle('cell', fontName='DV', fontSize=8, leading=11, textColor=INK)
cellh = ParagraphStyle('cellh', fontName='DV-B', fontSize=7.2, leading=9, textColor=GREY)
cellb = ParagraphStyle('cellb', fontName='DV-B', fontSize=8.2, leading=11, textColor=INK)
trans = ParagraphStyle('trans', fontName='DV-I', fontSize=8.2, leading=11, textColor=INK)

FW = W - 2 * M  # frame width


def P(t, st=body):
    return Paragraph(t, st)


def callout(text, bg=TINT, bar=TEAL):
    t = Table([[Paragraph(text, body)]], colWidths=[FW])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), bg), ('LINEBEFORE', (0, 0), (0, -1), 3, bar),
        ('LEFTPADDING', (0, 0), (-1, -1), 10), ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]))
    return t


def ex(text, tr, s=2.0, roman=True):
    rows = [[Script(text, s=s, roman=roman)]]
    if tr:
        rows.append([Paragraph(tr, trans)])
    t = Table(rows, colWidths=[FW])
    t.setStyle(TableStyle([
        ('LINEBELOW', (0, -1), (-1, -1), 0.6, GUIDE), ('NOSPLIT', (0, 0), (-1, -1)),
        ('LEFTPADDING', (0, 0), (-1, -1), 4), ('RIGHTPADDING', (0, 0), (-1, -1), 4),
        ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
    return t


def gtable(rows, widths, header=None, valign='MIDDLE'):
    data = ([[Paragraph(h, cellh) for h in header]] if header else []) + rows
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    st = [('VALIGN', (0, 0), (-1, -1), valign),
          ('LINEBELOW', (0, 0), (-1, -1), 0.5, GUIDE),
          ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
          ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]
    if header:
        st.append(('BACKGROUND', (0, 0), (-1, 0), TINT))
    t.setStyle(TableStyle(st))
    return t


def G(key, label=None, flags=(), s=1.9):
    return Glyph(key, flags, s=s, label=label if label is not None else key)


# ----------------------------------------------------------------- pages
def draw_cover(c, doc):
    c.setFillColor(NAVY)
    c.rect(0, 0, W, H, stroke=0, fill=1)
    rnd = random.Random(11)
    keys = list(SPEC) + list(VOW)
    for gy in range(-10, int(H), 46):
        for gx in range(-6, int(W), 30):
            k = rnd.choice(keys)
            fl = ()
            if k in VOW and rnd.random() < .25:
                fl = ('long',)
            if k in ASP and rnd.random() < .25:
                fl = ('asp',)
            draw_glyph(c, k, gx + rnd.uniform(-3, 3), gy + rnd.uniform(-3, 3), 2.3, fl, colors.HexColor('#1b1f4a'))
    # title plate
    c.setFillColor(NAVY)
    c.roundRect(24, 150, W - 48, 330, 10, stroke=0, fill=1)
    s = 6.2
    for i, wd in enumerate(['gupt', 'bhasa']):
        toks = parse_word(wd)
        ww = word_width(toks, s)
        draw_tokens(c, toks, (W - ww) / 2, 365 - i * 100, s, GOLD, True)
    c.setStrokeColor(GOLD)
    c.setLineWidth(0.8)
    c.line(W / 2 - 40, 240, W / 2 + 40, 240)
    c.setFillColor(colors.white)
    c.setFont('DV-B', 11)
    c.drawCentredString(W / 2, 218, 'A SECRET LANGUAGE')
    c.setFont('DV', 8.5)
    c.setFillColor(colors.HexColor('#b9bfdc'))
    c.drawCentredString(W / 2, 200, 'Book One \u2014 Letters, Words & Grammar')
    c.setFont('DV', 7)
    c.drawCentredString(W / 2, 26, 'Learning edition \u00b7 includes the Roman key')


def draw_page(c, doc):
    c.setFont('DV', 7)
    c.setFillColor(GREY)
    c.drawString(M, 20, 'GUPT \u00b7 Book One')
    c.drawRightString(W - M, 20, str(doc.page - 1))
    c.setStrokeColor(GUIDE)
    c.setLineWidth(0.6)
    c.line(M, 30, W - M, 30)


doc = BaseDocTemplate(OUT, pagesize=A5, title='Gupt \u2014 Learning Book One', author='',
                      leftMargin=M, rightMargin=M, topMargin=M, bottomMargin=M + 6)
doc.addPageTemplates([
    PageTemplate(id='cover', frames=[Frame(0, 0, W, H, id='c')], onPage=draw_cover),
    PageTemplate(id='main', frames=[Frame(M, M + 6, FW, H - 2 * M - 6, id='m')], onPage=draw_page)])

S = []
S += [Spacer(1, 1), NextPageTemplate('main'), PageBreak()]

# ================================================================ WELCOME
S += [P('Welcome to Gupt', h1),
      P('Gupt is a constructed language with its own script and its own grammar. '
        'It has no Latin letters in it: every word is built from 30 shapes that you will '
        'learn in the first part of this book. The shapes are not random. Each one tells you '
        '<b>where</b> a sound is made in the mouth and <b>how</b>, so you learn a system, not 30 separate pictures.'),
      callout('<b>Three golden rules</b><br/>'
              '1. One glyph = one sound. Nothing is silent, nothing is an exception.<br/>'
              '2. Words hang from a headline, and you read left to right.<br/>'
              '3. Gupt is written the way it sounds, whether the word is Gupt, Hindi or English.'),
      Spacer(1, 8), P('How examples are shown', h2),
      P('Glyphs come first. The small grey line under each word is the <b>Roman key</b>, '
        'there to help you learn. Cover it with a finger and test yourself.'),
      ex('mi ve jal to piv.', 'I drink water.', s=2.4),
      P('Your learning path', h2)]
path = [[P('<b>Part 1</b>', cell), P('The Script \u2014 30 letters, 2 marks, and how to write them', cell)],
        [P('<b>Part 2</b>', cell), P('Reading \u2014 your first words and a core vocabulary of about 70', cell)],
        [P('<b>Part 3</b>', cell), P('Grammar \u2014 eight rules, then a short story to read', cell)],
        [P('<b>Part 4</b>', cell), P('Chemistry mode, Hinglish and writing English words', cell)],
        [P('<b>Part 5</b>', cell), P('Practice \u2014 exercises, answer key, quick reference, notes', cell)]]
S += [gtable(path, [50, FW - 50]), PageBreak()]

# ================================================================ PART 1
S += [Banner('Part 1', 'The Script', 'lipi'), Spacer(1, 0),
      P('1.1  Five families of shapes', h2),
      P('Every consonant starts from one of five base shapes. The shape tells you the <b>place</b> '
        'where the sound is made.')]
fam_rows = [
    [G('p', '', s=1.5), P('<b>Lips</b> \u2014 a ring, like lips saying \u201coh\u201d', cell), P('p  b  m  f  v  w', cell)],
    [G('t', '', s=1.5), P('<b>Teeth</b> \u2014 a pointed triangle, tongue tip on the teeth', cell), P('t  d  n  s  z  l  r', cell)],
    [G('T', '', s=1.5), P('<b>Curl</b> \u2014 the same triangle upside down: tongue curled back (Hindi retroflex sounds)', cell), P('T  D  N', cell)],
    [G('c', '', s=1.5), P('<b>Roof</b> \u2014 an arch, like the roof of the mouth', cell), P('c  j  \u00f1  x  y', cell)],
    [G('k', '', s=1.5), P('<b>Throat</b> \u2014 a straight stem, like the windpipe', cell), P('k  g  G  h', cell)]]
S += [gtable(fam_rows, [40, 220, FW - 260]), Spacer(1, 0),
      P('1.2  The marks', h2),
      P('A small mark on the base shape tells you the <b>manner</b>: how the sound is made. '
        'The same marks work in every family.')]
mk = [
    [G('b', '', s=1.4), P('<b>Dot</b>', cellb), P('adds a buzz (voice): p \u2192 b', cell)],
    [G('m', '', s=1.4), P('<b>Underline</b>', cellb), P('the sound goes through the nose: p \u2192 m', cell)],
    [G('f', '', s=1.4), P('<b>Bar</b>', cellb), P('air hisses through: p \u2192 f', cell)],
    [G('v', '', s=1.4), P('<b>Bar + dot</b>', cellb), P('a hiss with a buzz: f \u2192 v', cell)],
    [G('w', '', s=1.4), P('<b>Two dots</b>', cellb), P('a gliding sound: w, l, y', cell)],
    [G('r', '', s=1.4), P('<b>Zigzag</b>', cellb), P('the tongue rolls (only r)', cell)],
    [G('k', '', ('asp',), s=1.4), P('<b>Ring (puff)</b>', cellb),
     P('a puff of breath: k \u2192 kh, p \u2192 ph, and so on', cell)],
    [G('a', '', ('long',), s=1.4), P('<b>Long bar</b>', cellb), P('vowels only: hold the vowel twice as long (aa, ii, uu)', cell)]]
S += [gtable(mk, [44, 76, FW - 120]), PageBreak()]

# ---- vowels, then consonant map
vw = [
    [G('a', '', s=1.8), P('<b>a</b>', cellb), P('about, or Hindi short a', cell), P('a dot \u2014 the smallest sound, the smallest mark', cell)],
    [G('e', '', s=1.8), P('<b>e</b>', cellb), P('they, or Hindi e', cell), P('e lies flat', cell)],
    [G('i', '', s=1.8), P('<b>i</b>', cellb), P('sit, or Hindi short i', cell), P('i stands tall', cell)],
    [G('o', '', s=1.8), P('<b>o</b>', cellb), P('go, or Hindi o', cell), P('o is round', cell)],
    [G('u', '', s=1.8), P('<b>u</b>', cellb), P('put, or Hindi short u', cell), P('u is a cup', cell)]]
S += [KeepTogether([P('1.3  The five vowels', h2), gtable(vw, [40, 24, 120, FW - 184]),
                    P('Add the long bar for the long sounds: aa (father), ii (see), uu (moon). '
                      'Diphthongs are two glyphs: ai, au.', body)])]
cols = ['plain', 'voiced', 'nasal', 'hiss', 'buzz', 'glide', 'trill']
mp = {'lip': 'Lips', 'tee': 'Teeth', 'ret': 'Curl', 'pal': 'Roof', 'thr': 'Throat'}
grid = [[P('', cellh)] + [P(m, cellh) for m in
                           ['plain', 'dot', 'under-<br/>line', 'bar', 'bar +<br/>dot', 'two<br/>dots', 'zigzag']]]
for fam in ['lip', 'tee', 'ret', 'pal', 'thr']:
    row = [P('<b>%s</b>' % mp[fam], cell)]
    for m in cols:
        k = [kk for kk, v in SPEC.items() if v == (fam, m)]
        row.append(G(k[0], k[0], s=1.9) if k else '')
    grid.append(row)
gt = Table(grid, colWidths=[46] + [(FW - 46) / 7.0] * 7, rowHeights=[22] + [44] * 5)
gt.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
                        ('BACKGROUND', (0, 0), (-1, 0), TINT), ('LINEBELOW', (0, 0), (-1, -1), 0.5, GUIDE),
                        ('BACKGROUND', (0, 1), (0, -1), TINT)]))
S += [KeepTogether([P('1.4  The consonant map', h2),
                    P('All 25 consonants on one grid. Read across for manner, down for place.'), gt]),
      PageBreak()]

# ---- sounds & hooks
S += [callout('<b>Spelling note.</b> Gupt letter codes are single characters: <b>c</b> is the sound \u201cch\u201d as in chair, '
              '<b>x</b> is \u201csh\u201d, <b>\u00f1</b> is \u201cny\u201d, <b>G</b> is \u201cng\u201d. In the Roman key, '
              'a letter followed by <b>h</b> means the breath ring: <b>kh</b> = k + ring, '
              '<b>ch</b> = c + ring (the breathy Hindi chh), <b>sh</b> = one glyph, x.'),
      P('1.5  Sound and shape, family by family', h2)]
FAMROWS = {
    'Lips': [('p', 'pin', 'plain ring'), ('b', 'bin', 'ring + dot'), ('m', 'man', 'ring + underline'),
             ('f', 'fan', 'ring + bar'), ('v', 'van', 'ring + bar + dot'), ('w', 'we (a soft v)', 'ring + two dots')],
    'Teeth': [('t', 'Hindi t, tongue on the teeth', 'plain triangle'), ('d', 'Hindi d, tongue on the teeth', 'triangle + dot'),
              ('n', 'no', 'triangle + underline'), ('s', 'sun', 'triangle + bar'), ('z', 'zoo', 'triangle + bar + dot'),
              ('l', 'lamp', 'triangle + two dots'), ('r', 'red, lightly rolled', 'triangle + zigzag')],
    'Curl': [('T', 'Hindi T, or English t in \u201ctin\u201d', 'upside-down triangle'), ('D', 'Hindi D, or English d in \u201cden\u201d', 'upside-down triangle + dot'),
             ('N', 'Hindi N', 'upside-down triangle + underline')],
    'Roof': [('c', 'chair', 'plain arch'), ('j', 'jam', 'arch + dot'), ('\u00f1', 'canyon (ny)', 'arch + underline'),
             ('x', 'ship (sh)', 'arch + bar'), ('y', 'yes', 'arch + two dots')],
    'Throat': [('k', 'kite', 'plain stem'), ('g', 'go', 'stem + dot'), ('G', 'sing (ng)', 'stem + underline'),
               ('h', 'hat', 'stem + bar')]}
for name, rws in FAMROWS.items():
    S.append(KeepTogether([
        P(name, ParagraphStyle('f', parent=cellb, spaceBefore=4, spaceAfter=1, textColor=TEAL)),
        gtable([[G(k, '', s=1.6), P('<b>%s</b>' % k, cellb), P(snd, cell), P(bd, cell)] for k, snd, bd in rws],
               [36, 24, 150, FW - 210])]))
S.append(CondPageBreak(300))

# ---- writing rules
S += [P('1.6  How to write it', h2),
      P('<b>1. Draw the headline first.</b> Rule a straight line for each word and hang the glyphs below it. '
        'The line shows where one word stops and the next begins.'),
      P('<b>2. Write left to right.</b> Leave a gap about the width of one glyph between words.'),
      P('<b>3. Base shape first, marks second.</b> Draw the ring, triangle, arch or stem, then add the dot, bar or underline. '
        'Dots are small; do not let them grow.'),
      P('<b>4. End a sentence with a dot</b> sitting on the baseline, not the middle, so it is never confused '
        'with the vowel a, which floats in the middle.'),
      P('<b>5. Suffixes are joined to the word.</b> The Roman key shows a hyphen (piv-ak) only so you can see the pieces. '
        'In Gupt script they sit under the same headline.'),
      ex('piv piv-ak piv-ul.', 'Same word, three tenses.', s=2.2),
      Spacer(1, 4)]
ref = [['a', 'e', 'i', 'o', 'u', 'aa', 'kh'],
       ['p', 'b', 'm', 'f', 'v', 'w', ''], ['t', 'd', 'n', 's', 'z', 'l', 'r'],
       ['T', 'D', 'N', '', '', '', ''], ['c', 'j', '\u00f1', 'x', 'y', '', ''], ['k', 'g', 'G', 'h', '', '', '']]
rg = []
for r in ref:
    row = []
    for k in r:
        if not k:
            row.append('')
        elif k == 'aa':
            row.append(Glyph('a', ('long',), s=2.0, label='aa'))
        elif k == 'kh':
            row.append(Glyph('k', ('asp',), s=2.0, label='kh'))
        else:
            row.append(Glyph(k, (), s=2.0, label=k))
    rg.append(row)
rt = Table(rg, colWidths=[FW / 7.0] * 7, rowHeights=[44] * 6)
rt.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                        ('BOX', (0, 0), (-1, -1), 0.6, GUIDE), ('INNERGRID', (0, 0), (-1, -1), 0.4, GUIDE),
                        ('BACKGROUND', (0, 0), (-1, 0), TINT)]))
S += [KeepTogether([P('1.7  Alphabet at a glance', h2), rt]), PageBreak()]

# ---- practice sheets
S += [P('1.8  Practice sheets', h2),
      P('Trace the grey glyphs, then write the glyph yourself in the empty boxes. '
        'Say the sound out loud each time.', body), Spacer(1, 2)]
items = [('a', (), 'a'), ('e', (), 'e'), ('i', (), 'i'), ('o', (), 'o'), ('u', (), 'u'), ('a', ('long',), 'aa')]
for fam in ['lip', 'tee', 'ret', 'pal', 'thr']:
    for k, v in SPEC.items():
        if v[0] == fam:
            items.append((k, (), k))
items.append(('k', ('asp',), 'kh'))
for i in range(0, len(items), 2):
    S.append(TraceRow(items[i:i + 2], cw=33, ch=50, s=2.4))
    if i == 14:
        S.append(PageBreak())
S.append(PageBreak())

# ================================================================ PART 2
S += [Banner('Part 2', 'Reading Your First Words', 'sabd'), Spacer(1, 10),
      P('2.1  Warm-up: say it out loud', h2),
      P('Each line below is one family of consonants joined to a vowel. Read each syllable, then check the grey key.')]
for line in ['ma mi mu me mo', 'pa ba ma fa va wa', 'ta da na sa za la ra', 'Ta Da Na', 'ca ja \u00f1a xa ya',
             'ka ga Ga ha', 'kha gha pha bha tha dha']:
    S.append(ex(line, '', s=1.9))
S += [KeepTogether([P('2.2  Your first ten words', h2),
      ex('mi tu so jal ghar roTi kitab mitra dudh phal', '', s=1.9),
      P('<b>mi</b> I \u00b7 <b>tu</b> you \u00b7 <b>so</b> he, she, it \u00b7 <b>jal</b> water \u00b7 <b>ghar</b> house \u00b7 '
        '<b>roTi</b> bread \u00b7 <b>kitab</b> book \u00b7 <b>mitra</b> friend \u00b7 <b>dudh</b> milk \u00b7 <b>phal</b> fruit', small)])]


def vocab(entries):
    rows = []
    for i in range(0, len(entries), 2):
        a = entries[i]
        b = entries[i + 1] if i + 1 < len(entries) else None
        row = [Script(a[0], s=1.5, roman=False), P('<b>%s</b><br/>%s' % a, cell)]
        row += [Script(b[0], s=1.5, roman=False), P('<b>%s</b><br/>%s' % b, cell)] if b else ['', '']
        rows.append(row)
    return gtable(rows, [92, 83, 92, FW - 267])


S += [P('2.3  Core vocabulary', h2),
      P('Roots are borrowed from Hindi, Sanskrit and English and reshaped to fit the Gupt sounds.', small), Spacer(1, 3)]
V = {
    'People and pronouns': [('mi', 'I'), ('tu', 'you'), ('so', 'he, she, it'), ('mi-ni', 'we'), ('tu-ni', 'you (all)'),
                            ('so-ni', 'they'), ('mitra', 'friend'), ('guru', 'teacher'), ('chatra', 'student')],
    'Little words': [('ve', 'doer marker'), ('to', 'receiver marker'), ('ne', 'at, in, on'), ('na', 'not'),
                     ('ka', 'question marker'), ('ar', 'and'), ('aj', 'today'), ('bhi', 'also')],
    'Things': [('jal', 'water'), ('kitab', 'book'), ('ghar', 'house'), ('nad', 'river'), ('ag', 'fire'), ('vayu', 'air'),
               ('dharti', 'earth'), ('cand', 'moon'), ('surya', 'sun'), ('dudh', 'milk'), ('roTi', 'bread'),
               ('phal', 'fruit'), ('prayog', 'experiment'), ('tatva', 'element')],
    'Doing words (stems)': [('piv', 'drink'), ('kha', 'eat'), ('ja', 'go'), ('ay', 'come'), ('kar', 'do, make'),
                            ('dekh', 'see'), ('sun', 'hear'), ('pad', 'read'), ('lekh', 'write'), ('jan', 'know'),
                            ('bol', 'speak'), ('de', 'give'), ('le', 'take'), ('mil', 'meet, mix'), ('sikh', 'learn')],
    'Describing words': [('bada', 'big'), ('choTa', 'small'), ('nay', 'new'), ('acha', 'good'), ('bura', 'bad'),
                         ('tez', 'fast'), ('lal', 'red'), ('nil', 'blue'), ('hara', 'green')],
    'Numbers': [('ek', 'one'), ('do', 'two'), ('tin', 'three'), ('car', 'four'), ('panc', 'five')]}
for name, ents in V.items():
    S.append(KeepTogether([P(name, ParagraphStyle('vh', parent=cellb, spaceBefore=5, spaceAfter=1, textColor=TEAL)),
                           vocab(ents)]))
S.append(PageBreak())

# ================================================================ PART 3
def rule(title, *fl):
    return KeepTogether([P(title, h2)] + list(fl))


S += [Banner('Part 3', 'Grammar in Eight Rules', 'vyakaran'), Spacer(1, 6),
      P('Gupt grammar is small and regular on purpose: no genders, no irregular verbs, no exceptions to memorise.'),
      rule('Rule 1 \u2014 The verb comes last',
           P('The doer comes first, then the thing acted on, then the verb: Subject, Object, Verb. This is the same order as Hindi.'),
           ex('mi ve jal to piv.', 'I drink water.', s=2.0),
           ex('tu ve kitab to pad.', 'You read a book.', s=2.0)),
      rule('Rule 2 \u2014 Small particles tag the roles',
           P('<b>ve</b> tags the doer, <b>to</b> tags the thing acted on, <b>ne</b> tags a place (at, in, on). '
             'A particle goes straight after its word and never changes.'),
           ex('so ve roTi to kha.', 'He eats bread.', s=2.0),
           ex('mitra ve nad ne.', 'The friend is at the river.', s=2.0)),
      rule('Rule 3 \u2014 There is no \u201cto be\u201d',
           P('Gupt has no word for am, is or are. Just put the doer and the description side by side.'),
           ex('mi ve chatra.', 'I am a student.', s=2.0),
           ex('so ve acha guru.', 'She is a good teacher.', s=2.0),
           ex('kitab ve ghar ne.', 'The book is in the house.', s=2.0)),
      rule('Rule 4 \u2014 Tense is a suffix on the verb',
           P('Present = the bare stem. Past = <b>-ak</b>. Future = <b>-ul</b>. The suffix is the same after every stem, '
             'including stems that end in a vowel (kha-ak, de-ul).'),
           ex('mi ve jal to piv.', 'I drink water.', s=1.9),
           ex('mi ve jal to piv-ak.', 'I drank water.', s=1.9),
           ex('mi ve jal to piv-ul.', 'I will drink water.', s=1.9)),
      rule('Rule 5 \u2014 Plural is -i, or -ni after a vowel',
           P('Add <b>-i</b> to a word that ends in a consonant and <b>-ni</b> to a word that ends in a vowel. '
             'After a number the noun stays singular.'),
           ex('kitab-i ghar-i', 'books, houses', s=2.0),
           ex('mi-ni tu-ni so-ni chatra-ni', 'we, you (all), they, students', s=1.9),
           ex('tin ghar', 'three houses', s=2.0)),
      rule('Rule 6 \u2014 No, and questions',
           P('Put <b>na</b> right before the verb to say no. Put <b>ka</b> at the very end to ask a question.'),
           ex('mi ve jal to na piv.', 'I do not drink water.', s=1.9),
           ex('tu ve jal to piv ka.', 'Do you drink water?', s=1.9),
           ex('tu ve roTi to na kha-ak ka.', 'Did you not eat bread?', s=1.9)),
      rule('Rule 7 \u2014 Describing words come first and never change',
           ex('bada ghar', 'a big house', s=2.0),
           ex('bada ghar-i', 'big houses', s=2.0),
           ex('nay kitab-i', 'new books', s=2.0)),
      rule('Rule 8 \u2014 Join ideas with ar',
           ex('mi ve roTi to kha-ak ar jal to piv-ak.', 'I ate bread and drank water.', s=1.8)),
      rule('Reading practice: an afternoon at home',
           P('Read each sentence aloud. Try it without the grey key first.', small),
           ex('mi ve ghar ne.', 'I am at home.', s=1.9),
           ex('mi ve roTi to kha-ak.', 'I ate bread.', s=1.9),
           ex('mitra ve aj ay-ul.', 'A friend will come today.', s=1.9),
           ex('mi-ni ve dudh to piv-ul ar kitab to pad-ul.', 'We will drink milk and read a book.', s=1.8),
           ex('tu ve aj ay-ul ka.', 'Will you come today?', s=1.9),
           ex('tu ve acha mitra.', 'You are a good friend.', s=1.9)),
      PageBreak()]

# ================================================================ PART 4
S += [Banner('Part 4', 'Chemistry, Hinglish & English', 'rasayan'), Spacer(1, 10),
      P('4.1  Chemistry mode', h2),
      P('Chemistry keeps its own rules so formulas stay exact.'),
      P('<b>1. A double headline</b> tells the reader: this is chemistry.'),
      P('<b>2. Spell element symbols letter by letter</b> using the glyph for each letter. '
        'Three letters need care: C uses the glyph c (ch), X is written k + s, and Q is written k.'),
      P('<b>3. Capitals wear a small flag</b> above the first glyph of a symbol. '
        'That is how Co (cobalt, one flag) differs from CO (carbon monoxide, two flags).'),
      P('<b>4. Numbers stay ordinary digits</b>: small and low after a symbol (H<sub>2</sub>O), '
        'large in front for coefficients (2H<sub>2</sub>O). Plus, arrows and brackets work as usual.'),
      Spacer(1, 4)]
chem = [('H2O', 'water'), ('CO2', 'carbon dioxide'), ('NaCl', 'table salt'), ('CH4', 'methane'),
        ('NaOH', 'sodium hydroxide'), ('H2SO4', 'sulfuric acid'), ('Ca(OH)2', 'calcium hydroxide'),
        ('Fe2O3', 'iron(III) oxide'), ('Co', 'cobalt'), ('CO', 'carbon monoxide')]
rows = []
for i in range(0, len(chem), 2):
    a, b = chem[i], chem[i + 1]
    rows.append([Script('[[%s]]' % a[0], s=1.5), P(a[1], cell), Script('[[%s]]' % b[0], s=1.5), P(b[1], cell)])
S += [gtable(rows, [88, 85, 88, FW - 261]), Spacer(1, 6),
      KeepTogether([P('A reaction', h2),
      ex('[[2H2 + O2 \u2192 2H2O]]', 'Two hydrogen molecules plus one oxygen molecule give two water molecules.', s=1.8)]),
      P('Chemistry inside a sentence', h2),
      ex('jal ve [[H2O]].', 'Water is H\u2082O.', s=1.9),
      ex('mi ve [[NaCl]] to jal ne mil-ak.', 'I mixed NaCl into water.', s=1.8),
      ex('tatva ve [[Na]].', 'The element is Na (sodium).', s=1.9),
      Spacer(1, 2)]

S += [P('4.2  Writing Hindi and Hinglish', h2),
      P('Gupt was built to carry Hindi sounds, so Hindi words are written exactly as they sound. '
        'The curl glyphs T D N cover the retroflex sounds, and the ring covers the breathy ones (kh, gh, ph, bh, th, dh). '
        'Plain \u201cch\u201d as in chai is the bare glyph c; add the ring only for Hindi chh.'),
      ex('namaste dhanyavad', 'hello, thank you', s=1.9),
      ex('aap kaise hain', 'how are you (polite)', s=1.9), ex('paani caay khaana', 'water, tea, food', s=1.9),
      P('4.3  Writing English by sound', h2),
      P('Never copy English spelling. Write the sounds you hear. English \u201cth\u201d becomes t or d.'),
      ex('buk skuul fon helo', 'book, school, phone, hello', s=1.9),
      ex('kampyuTar', 'computer', s=1.9),
      callout('<b>Why Book Two?</b> Numbers stay ordinary digits in this book. '
              'Book Two can add a full set of Gupt numerals, a way to write punctuation, and longer stories.'),
      PageBreak()]

# ================================================================ PART 5
S += [Banner('Part 5', 'Practice', 'abhyas'), Spacer(1, 6),
      P('Exercise A \u2014 Read these words', h2),
      P('No key this time. Say each one, then check the answer key.', small), Spacer(1, 3),
      Script('jal ghar roTi mitra kitab-i piv-ak bada dudh', s=2.0, roman=False), Spacer(1, 8),
      P('Exercise B \u2014 Read these sentences', h2),
      Script('so ve ghar ne.', s=1.9, roman=False), Spacer(1, 4),
      Script('tu ve nay kitab to pad-ak ka.', s=1.9, roman=False), Spacer(1, 4),
      Script('mi ve [[H2O]] to na piv.', s=1.9, roman=False), Spacer(1, 8),
      PageBreak(),
      KeepTogether([P('Exercise C \u2014 Write in Gupt', h2),
      P('1. I drink milk.<br/>2. You will read a book.<br/>3. The friend ate bread.<br/>'
        '4. Do you eat fruit?<br/>5. We are students.'),
      WriteLines(5, 40, 2.0)]), Spacer(1, 6),
      KeepTogether([P('Exercise D \u2014 Write these formulas in chemistry mode', h2),
      P('H<sub>2</sub>O &nbsp;\u00b7&nbsp; CO<sub>2</sub> &nbsp;\u00b7&nbsp; NaCl &nbsp;\u00b7&nbsp; H<sub>2</sub>SO<sub>4</sub>'),
      WriteLines(2, 46, 2.0)]), PageBreak()]

S += [P('Answer key', h2),
      P('<b>A.</b> jal (water), ghar (house), roTi (bread), mitra (friend), kitab-i (books), piv-ak (drank), bada (big), dudh (milk).'),
      P('<b>B.</b> 1. He/she is at the house. '
        '2. Did you read a new book? 3. I do not drink water.'),
      P('<b>C.</b> Check your glyphs against these.'),
      ex('mi ve dudh to piv.', '1. I drink milk.', s=1.7),
      ex('tu ve kitab to pad-ul.', '2. You will read a book.', s=1.7),
      ex('mitra ve roTi to kha-ak.', '3. The friend ate bread.', s=1.7),
      ex('tu ve phal to kha ka.', '4. Do you eat fruit?', s=1.7),
      ex('mi-ni ve chatra-ni.', '5. We are students.', s=1.7),
      P('<b>D.</b> Use the double headline, flags on every capital, and small low digits.'),
      ex('[[H2O]] [[CO2]] [[NaCl]] [[H2SO4]]', '', s=1.7),
      PageBreak()]

S += [P('Quick reference', h2)]
qr = [[P('<b>Word order</b>', cell), P('Subject, Object, Verb. The verb is last.', cell)],
      [P('<b>Particles</b>', cell), P('ve = doer \u00b7 to = receiver \u00b7 ne = place', cell)],
      [P('<b>Be</b>', cell), P('No verb. mi ve chatra = I am a student.', cell)],
      [P('<b>Tense</b>', cell), P('stem = now \u00b7 -ak = past \u00b7 -ul = future', cell)],
      [P('<b>Plural</b>', cell), P('-i after a consonant \u00b7 -ni after a vowel \u00b7 none after a number', cell)],
      [P('<b>No</b>', cell), P('na goes right before the verb.', cell)],
      [P('<b>Question</b>', cell), P('ka goes at the end.', cell)],
      [P('<b>Describing words</b>', cell), P('Before the noun. Never change.', cell)],
      [P('<b>And</b>', cell), P('ar', cell)],
      [P('<b>Chemistry</b>', cell), P('Double headline \u00b7 flag on every capital \u00b7 digits stay digits', cell)]]
S += [gtable(qr, [90, FW - 90]), Spacer(1, 8),
      P('Notes', h2), WriteLines(7, 40, 2.0)]

doc.build(S)
print('built', OUT)
