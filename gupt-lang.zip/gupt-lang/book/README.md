# Learning book generator

Builds `Gupt_Learning_Book.pdf` (A5, about 28 pages).

    pip install reportlab
    python build_book.py

Needs DejaVu Sans (Linux: `fonts-dejavu-core`). The prebuilt PDF is in `../docs/`.
`engine.py` draws glyphs with ReportLab and mirrors the geometry in `gupt/shapes.py`;
keep them in sync when you change a glyph.
