import re
from reportlab.lib import colors
from reportlab.platypus import Flowable
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.lib.fonts import addMapping

FD = '/usr/share/fonts/truetype/dejavu/'
pdfmetrics.registerFont(TTFont('DV', FD + 'DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DV-B', FD + 'DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I', FD + 'DejaVuSans-Oblique.ttf'))
pdfmetrics.registerFont(TTFont('DV-BI', FD + 'DejaVuSans-BoldOblique.ttf'))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily('DV', normal='DV', bold='DV-B', italic='DV-I', boldItalic='DV-BI')

INK = colors.HexColor('#1d2142')
GHOST = colors.HexColor('#c9cfe4')
GREY = colors.HexColor('#6b7194')
GUIDE = colors.HexColor('#dfe3f1')
GOLD = colors.HexColor('#d4a72c')
TEAL = colors.HexColor('#0f7f86')

GW = 9.0        # glyph advance (units)
HL = 11.6       # headline height
LW = 0.55       # stroke width (units)
DX = 0.5        # centring shift

VOW = 'aeiou'
SPEC = {
    'p': ('lip', 'plain'), 'b': ('lip', 'voiced'), 'm': ('lip', 'nasal'),
    'f': ('lip', 'hiss'), 'v': ('lip', 'buzz'), 'w': ('lip', 'glide'),
    't': ('tee', 'plain'), 'd': ('tee', 'voiced'), 'n': ('tee', 'nasal'),
    's': ('tee', 'hiss'), 'z': ('tee', 'buzz'), 'l': ('tee', 'glide'), 'r': ('tee', 'trill'),
    'T': ('ret', 'plain'), 'D': ('ret', 'voiced'), 'N': ('ret', 'nasal'),
    'c': ('pal', 'plain'), 'j': ('pal', 'voiced'), 'ñ': ('pal', 'nasal'),
    'x': ('pal', 'hiss'), 'y': ('pal', 'glide'),
    'k': ('thr', 'plain'), 'g': ('thr', 'voiced'), 'G': ('thr', 'nasal'), 'h': ('thr', 'hiss'),
}
ASP = set('pbtdTDcjkg')

# per-family geometry
FAM = {
    'lip': dict(dot=(4, 5.2), bar=(0.8, 5.2, 7.2, 5.2), bardot=(4, 7.0), two=((4, 6.6), (4, 3.8))),
    'tee': dict(dot=(4, 4.0), bar=(1.46, 3.2, 6.54, 3.2), bardot=(4, 5.3), two=((4, 5.2), (4, 3.0))),
    'ret': dict(dot=(4, 6.2)),
    'pal': dict(dot=(4, 4.0), bar=(1, 3.6, 7, 3.6), bardot=(4, 6.0), two=((4, 3.6), (4, 6.0))),
    'thr': dict(dot=(6.4, 5.2), bar=(2, 5.2, 6, 5.2)),
}


def draw_glyph(c, key, x, y, s, flags=(), color=INK):
    c.saveState()
    c.setStrokeColor(color)
    c.setFillColor(color)
    c.setLineWidth(LW * s)
    c.setLineCap(1)
    c.setLineJoin(1)

    def P(px, py):
        return (x + (px + DX) * s, y + py * s)

    def line(a, b, c2, d):
        c.line(*P(a, b), *P(c2, d))

    def ring(cx, cy, r):
        px, py = P(cx, cy)
        c.circle(px, py, r * s, stroke=1, fill=0)

    def dot(cx, cy, r=0.85):
        px, py = P(cx, cy)
        c.circle(px, py, r * s, stroke=0, fill=1)

    def arc(cx, cy, r, a0, ext):
        x1, y1 = P(cx - r, cy - r)
        x2, y2 = P(cx + r, cy + r)
        c.arc(x1, y1, x2, y2, a0, ext)

    def poly(pts, close=False):
        p = c.beginPath()
        p.moveTo(*P(*pts[0]))
        for q in pts[1:]:
            p.lineTo(*P(*q))
        if close:
            p.close()
        c.drawPath(p, stroke=1, fill=0)

    if key in VOW:
        if key == 'a':
            dot(4, 4.8, 1.2)
        elif key == 'e':
            line(1.9, 4.8, 6.1, 4.8)
        elif key == 'i':
            line(4, 2.6, 4, 7.0)
        elif key == 'o':
            ring(4, 4.8, 1.9)
        elif key == 'u':
            arc(4, 5.9, 2.2, 180, 180)
        if 'long' in flags:
            line(2.2, 1.4, 5.8, 1.4)
    else:
        fam, man = SPEC[key]
        F = FAM[fam]
        if fam == 'lip':
            ring(4, 5.2, 3.2)
        elif fam == 'tee':
            poly([(4, 8.6), (0.8, 1.8), (7.2, 1.8)], True)
        elif fam == 'ret':
            poly([(0.8, 8.6), (7.2, 8.6), (4, 1.8)], True)
        elif fam == 'pal':
            line(1, 1.8, 1, 5.6)
            arc(4, 5.6, 3, 0, 180)
            line(7, 5.6, 7, 1.8)
        elif fam == 'thr':
            line(4, 1.8, 4, 8.6)
        if man == 'voiced':
            dot(*F['dot'])
        elif man == 'nasal':
            line(2.3, 0.5, 5.7, 0.5)
        elif man == 'hiss':
            line(*F['bar'])
        elif man == 'buzz':
            line(*F['bar'])
            dot(*F['bardot'], 0.7)
        elif man == 'glide':
            for q in F['two']:
                dot(*q, 0.65)
        elif man == 'trill':
            poly([(2.0, 3.0), (3.0, 4.2), (4.0, 3.0), (5.0, 4.2), (6.0, 3.0)])
        if 'asp' in flags:
            ring(7.5, 9.9, 0.55)
    if 'cap' in flags:
        p = c.beginPath()
        p.moveTo(*P(2.9, 14.1))
        p.lineTo(*P(5.1, 14.1))
        p.lineTo(*P(4, 12.9))
        p.close()
        c.drawPath(p, stroke=0, fill=1)
    c.restoreState()


# ---------------------------------------------------------------- parsing
def parse_word(w):
    toks = []
    i = 0
    while i < len(w):
        ch = w[i]
        nxt = w[i + 1] if i + 1 < len(w) else ''
        if ch == '-':
            i += 1
            continue
        if ch == 's' and nxt == 'h':
            toks.append(('g', 'x', frozenset()))
            i += 2
        elif ch in VOW:
            if nxt == ch:
                toks.append(('g', ch, frozenset({'long'})))
                i += 2
            else:
                toks.append(('g', ch, frozenset()))
                i += 1
        elif ch in ASP and nxt == 'h':
            toks.append(('g', ch, frozenset({'asp'})))
            i += 2
        elif ch in SPEC:
            toks.append(('g', ch, frozenset()))
            i += 1
        else:
            raise ValueError('bad letter %r in %r' % (ch, w))
    return toks


def chem_letter(l):
    l = l.lower()
    if l == 'x':
        return ['k', 's']
    if l == 'q':
        return ['k']
    return [l]


def chem_tokens(src):
    toks = []
    i = 0
    prev = None
    while i < len(src):
        ch = src[i]
        if ch.isspace():
            toks.append(('sp',))
            prev = 'sp'
            i += 1
        elif ch.isdigit():
            j = i
            while j < len(src) and src[j].isdigit():
                j += 1
            kind = 'sub' if prev in ('el', 'pclose') else 'coef'
            toks.append(('dig', src[i:j], kind))
            prev = 'dig'
            i = j
        elif ch.isupper():
            sym = ch
            if i + 1 < len(src) and src[i + 1].islower():
                sym += src[i + 1]
            first = True
            for l in sym:
                for k in chem_letter(l):
                    toks.append(('g', k, frozenset({'cap'}) if first else frozenset()))
                    first = False
            prev = 'el'
            i += len(sym)
        elif ch in '()[]':
            toks.append(('par', ch))
            prev = 'pclose' if ch in ')]' else 'popen'
            i += 1
        elif ch in '+→=⇌':
            toks.append(('op', ch))
            prev = 'op'
            i += 1
        else:
            raise ValueError('bad chem char %r' % ch)
    return toks


def tok_adv(t, s):
    k = t[0]
    if k == 'g':
        return GW * s
    if k == 'dig':
        size = (4.6 if t[2] == 'sub' else 6.6) * s
        return stringWidth(t[1], 'DV-B', size) + 0.5 * s
    if k == 'par':
        return stringWidth(t[1], 'DV', 9 * s) + 0.3 * s
    if k == 'op':
        return stringWidth(t[1], 'DV-B', 7 * s) + 4 * s
    if k == 'sp':
        return 4 * s
    return 0


def draw_tokens(c, toks, x, y, s, color=INK, headline=True, chem=False):
    """draw tokens starting at x with glyph-box bottom at y; return end x"""
    segs = []
    cur = None
    for t in toks:
        w = tok_adv(t, s)
        k = t[0]
        if k == 'g':
            draw_glyph(c, t[1], x, y, s, t[2], color)
        elif k == 'dig':
            size = (4.6 if t[2] == 'sub' else 6.6) * s
            c.setFont('DV-B', size)
            c.setFillColor(color)
            c.drawString(x, y + (1.0 if t[2] == 'sub' else 3.0) * s, t[1])
        elif k == 'par':
            c.setFont('DV', 9 * s)
            c.setFillColor(color)
            c.drawString(x, y + 1.2 * s, t[1])
        elif k == 'op':
            c.setFont('DV-B', 7 * s)
            c.setFillColor(color)
            c.drawString(x + 2 * s, y + 2.6 * s, t[1])
        inline = k in ('g', 'par') or (k == 'dig' and t[2] == 'sub')
        if inline:
            if cur is None:
                cur = [x, x + w]
            else:
                cur[1] = x + w
        else:
            if cur:
                segs.append(cur)
            cur = None
        x += w
    if cur:
        segs.append(cur)
    if headline:
        c.saveState()
        c.setStrokeColor(color)
        c.setLineCap(1)
        c.setLineWidth(0.42 * s)
        for a, b in segs:
            c.line(a + 0.5 * s, y + HL * s, b - 0.5 * s, y + HL * s)
            if chem:
                c.line(a + 0.5 * s, y + (HL + 0.8) * s, b - 0.5 * s, y + (HL + 0.8) * s)
        c.restoreState()
    return x


def word_width(toks, s):
    return sum(tok_adv(t, s) for t in toks)


# ---------------------------------------------------------------- flowables
def build_items(text):
    items = []
    for m in re.finditer(r'\[\[(.+?)\]\]|(\S+)', text):
        if m.group(1):
            items.append(dict(kind='chem', raw=m.group(1), toks=chem_tokens(m.group(1)), dot=False))
        else:
            wd = m.group(2)
            dot = False
            while wd and wd[-1] in '.,':
                dot = dot or wd[-1] == '.'
                wd = wd[:-1]
            if wd:
                items.append(dict(kind='word', raw=wd, toks=parse_word(wd), dot=dot))
            elif dot and items:
                items[-1]['dot'] = True
    return items


class Script(Flowable):
    def __init__(self, text, s=2.2, roman=True, color=INK, align='left',
                 headline=True, lsize=7.0, gap=5.5):
        super().__init__()
        self.text = text
        self.s = s
        self.roman = roman
        self.color = color
        self.align = align
        self.headline = headline
        self.lsize = lsize
        self.gap = gap
        self.items = build_items(text)
        self.has_chem = any(i['kind'] == 'chem' for i in self.items)
        for it in self.items:
            gw = word_width(it['toks'], s) + (3.4 * s if it['dot'] else 0)
            lw = stringWidth(it['raw'] + ('.' if it['dot'] else ''), 'DV', lsize) + 2 if roman else 0
            it['gw'] = gw
            it['w'] = max(gw, lw)

    def wrap(self, aw, ah):
        s = self.s
        lines, cur, cw = [], [], 0
        sp = self.gap * s
        for it in self.items:
            if cur and cw + sp + it['w'] > aw:
                lines.append((cur, cw))
                cur, cw = [], 0
            cw += (sp if cur else 0) + it['w']
            cur.append(it)
        if cur:
            lines.append((cur, cw))
        self.lines = lines
        self.hbox = (14.4 if self.has_chem else 12.4) * s
        self.lbl = (self.lsize + 4) if self.roman else 0
        self.lh = self.hbox + self.lbl + 2
        self.width = aw
        self.height = max(1, len(lines)) * self.lh
        return aw, self.height

    def draw(self):
        c = self.canv
        s = self.s
        sp = self.gap * s
        for k, (its, cw) in enumerate(self.lines):
            y0 = self.height - (k + 1) * self.lh
            x = 0
            if self.align == 'center':
                x = (self.width - cw) / 2
            for it in its:
                gx = x + (it['w'] - it['gw']) / 2
                end = draw_tokens(c, it['toks'], gx, y0 + self.lbl + 1, s, self.color,
                                  self.headline, it['kind'] == 'chem')
                if it['dot']:
                    px = end + 1.5 * s
                    c.setFillColor(self.color)
                    c.circle(px, y0 + self.lbl + 1 + 1.3 * s, 0.8 * s, stroke=0, fill=1)
                if self.roman:
                    c.setFont('DV', self.lsize)
                    c.setFillColor(GREY)
                    c.drawCentredString(x + it['w'] / 2, y0 + 1,
                                        it['raw'] + ('.' if it['dot'] else ''))
                x += it['w'] + sp


class Glyph(Flowable):
    """single glyph in a fixed box, optional label"""
    def __init__(self, key, flags=(), s=2.4, w=None, label=None, color=INK, headline=False):
        super().__init__()
        self.key, self.flags, self.s = key, frozenset(flags), s
        self.w = w or GW * s + 6
        self.label = label
        self.color = color
        self.headline = headline

    def wrap(self, aw, ah):
        self.h = 12.4 * self.s + (11 if self.label else 0)
        return self.w, self.h

    def draw(self):
        c = self.canv
        s = self.s
        yb = 11 if self.label else 0
        draw_glyph(c, self.key, (self.w - GW * s) / 2, yb, s, self.flags, self.color)
        if self.headline:
            c.setStrokeColor(self.color)
            c.setLineWidth(0.42 * s)
            c.line(0.5 * s, yb + HL * s, self.w - 0.5 * s, yb + HL * s)
        if self.label:
            c.setFont('DV', 7.2)
            c.setFillColor(GREY)
            c.drawCentredString(self.w / 2, 1.5, self.label)


class TraceRow(Flowable):
    def __init__(self, pair, cw=32, ch=40, s=2.1, per=5):
        super().__init__()
        self.pair, self.cw, self.ch, self.s, self.per = pair, cw, ch, s, per

    def wrap(self, aw, ah):
        return aw, self.ch + 3

    def draw(self):
        c = self.canv
        s = self.s
        for gi, (key, flags, label) in enumerate(self.pair):
            x0 = gi * (self.per * self.cw + 14)
            for ci in range(self.per):
                x = x0 + ci * self.cw
                c.setStrokeColor(GUIDE)
                c.setLineWidth(0.6)
                c.rect(x, 0, self.cw, self.ch)
                gy = (self.ch - 12.4 * s) / 2
                c.setStrokeColor(GUIDE)
                c.line(x + 2, gy + HL * s, x + self.cw - 2, gy + HL * s)
                gx = x + (self.cw - GW * s) / 2
                if ci == 0:
                    draw_glyph(c, key, gx, gy, s, flags, INK)
                    c.setFont('DV', 6.2)
                    c.setFillColor(GREY)
                    c.drawString(x + 2, 2, label)
                elif ci <= 2:
                    draw_glyph(c, key, gx, gy, s, flags, GHOST)


class WriteLines(Flowable):
    def __init__(self, n=5, h=40, s=2.1):
        super().__init__()
        self.n, self.h, self.s = n, h, s

    def wrap(self, aw, ah):
        self.aw = aw
        return aw, self.n * self.h

    def draw(self):
        c = self.canv
        c.setLineWidth(0.6)
        for k in range(self.n):
            y = (self.n - 1 - k) * self.h
            gy = (self.h - 12.4 * self.s) / 2
            c.setStrokeColor(GUIDE)
            c.line(0, y + gy + HL * self.s, self.aw, y + gy + HL * self.s)
            c.line(0, y + gy + 1.6 * self.s, self.aw, y + gy + 1.6 * self.s)


class Banner(Flowable):
    def __init__(self, part, title, word, h=84):
        super().__init__()
        self.part, self.title, self.word, self.h = part, title, word, h

    def wrap(self, aw, ah):
        self.aw = aw
        return aw, self.h

    def draw(self):
        c = self.canv
        c.setFillColor(colors.HexColor('#12152e'))
        c.roundRect(0, 0, self.aw, self.h, 8, stroke=0, fill=1)
        c.setFillColor(GOLD)
        c.setFont('DV-B', 7.5)
        c.drawString(16, self.h - 20, self.part.upper())
        c.setFillColor(colors.white)
        c.setFont('DV-B', 17)
        c.drawString(16, self.h - 42, self.title)
        toks = parse_word(self.word)
        s = 2.2
        w = word_width(toks, s)
        draw_tokens(c, toks, self.aw - w - 14, 7, s, GOLD, True)
