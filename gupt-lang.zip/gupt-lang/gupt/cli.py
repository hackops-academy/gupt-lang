"""Command line interface: `gupt` (also `python -m gupt`)."""
import argparse
import os
import shutil
import subprocess
import sys

from . import __version__
from .core import GuptError, codepoint_table, decode, encode

MONO_CANDIDATES = [
    "/system/fonts/DroidSansMono.ttf",                      # Android / Termux
    "/system/fonts/CutiveMono.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",  # Kali / Debian / Ubuntu
    "/usr/share/fonts/dejavu/DejaVuSansMono.ttf",           # Fedora / Arch
    "/usr/share/fonts/TTF/DejaVuSansMono.ttf",
]


def is_termux():
    return "com.termux" in os.environ.get("PREFIX", "") or os.path.isdir("/data/data/com.termux")


def _read_text(args):
    if getattr(args, "file", None):
        with open(args.file, encoding="utf-8") as fh:
            return fh.read()
    if args.text:
        return " ".join(args.text)
    if not sys.stdin.isatty():
        return sys.stdin.read()
    sys.exit("gupt: give some text, use -f FILE, or pipe text in")


def _out(s, args):
    path = getattr(args, "output", None)
    if path:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(s)
        print("wrote", path, file=sys.stderr)
    else:
        sys.stdout.write(s if s.endswith("\n") else s + "\n")


def cmd_enc(a):
    _out(encode(_read_text(a), strict=a.strict, subscripts=not a.no_subscripts), a)


def cmd_dec(a):
    _out(decode(_read_text(a)), a)


def cmd_svg(a):
    from .render import to_svg
    text = _read_text(a)
    _out(to_svg(text, scale=a.scale, color=a.color, background=a.background,
                caption=text.strip() if a.caption else None), a)


def cmd_png(a):
    try:
        import cairosvg
    except ImportError:
        sys.exit("gupt png needs cairosvg:  pip install 'gupt-lang[png]'  (or use `gupt svg`)")
    from .render import to_svg
    svg = to_svg(_read_text(a), scale=a.scale, color=a.color, background=a.background or "white")
    cairosvg.svg2png(bytestring=svg.encode(), write_to=a.output)
    print("wrote", a.output, file=sys.stderr)


def cmd_table(a):
    print("| Codepoint | Glyph | Roman key | Meaning |\n|---|---|---|---|")
    for cp, roman, desc in codepoint_table():
        print("| U+%04X | %s | %s | %s |" % (cp, chr(cp), roman, desc))


def cmd_check(a):
    bad = 0
    with open(a.file, encoding="utf-8") as fh:
        for n, line in enumerate(fh, 1):
            try:
                encode(line, strict=True)
            except GuptError as e:
                bad += 1
                print("%s:%d: %s" % (a.file, n, e))
    print("%d problem line(s)" % bad)
    return 1 if bad else 0


def cmd_repl(a):
    try:
        import readline  # noqa: F401
    except ImportError:
        pass
    print("Gupt %s  |  type Roman key text, :dec <gupt text>, :q to quit" % __version__)
    while True:
        try:
            line = input("gupt> ")
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if line.strip() in (":q", ":quit", "exit"):
            return
        if line.startswith(":dec "):
            print(decode(line[5:]))
        elif line.strip():
            print(encode(line))


def _find_base(explicit):
    if explicit:
        return explicit
    for p in MONO_CANDIDATES:
        if os.path.exists(p):
            return p
    sys.exit("gupt: no base monospace TrueType font found. Pass one with --base /path/font.ttf")


def cmd_font(a):
    from .font import build_font, patch_font
    if a.action == "build":
        print("wrote", build_font(a.output or "Gupt-Regular.ttf"))
    elif a.action == "patch":
        print("wrote", patch_font(_find_base(a.base), a.output or "GuptMono-Regular.ttf"))
    elif a.action == "install":
        home = os.path.expanduser("~")
        if is_termux():
            os.makedirs(os.path.join(home, ".termux"), exist_ok=True)
            dest = os.path.join(home, ".termux", "font.ttf")
            if os.path.exists(dest) and not os.path.exists(dest + ".bak"):
                shutil.copy(dest, dest + ".bak")
                print("backed up your old font to", dest + ".bak")
            patch_font(_find_base(a.base), dest)
            print("installed", dest)
            if shutil.which("termux-reload-settings"):
                subprocess.call(["termux-reload-settings"])
            else:
                print("now run: termux-reload-settings   (or restart Termux)")
        else:
            fdir = os.path.join(os.environ.get("XDG_DATA_HOME", os.path.join(home, ".local", "share")), "fonts")
            os.makedirs(fdir, exist_ok=True)
            build_font(os.path.join(fdir, "Gupt-Regular.ttf"))
            print("installed", os.path.join(fdir, "Gupt-Regular.ttf"))
            if a.mono:
                patch_font(_find_base(a.base), os.path.join(fdir, "GuptMono-Regular.ttf"))
                print("installed", os.path.join(fdir, "GuptMono-Regular.ttf"), "(set your terminal font to 'Gupt Mono')")
            if shutil.which("fc-cache"):
                subprocess.call(["fc-cache", "-f", fdir])
            print("restart your terminal, then try:  gupt enc 'mi ve jal to piv.'")


def cmd_doctor(a):
    print("gupt", __version__)
    print("platform :", "Termux" if is_termux() else sys.platform)
    print("python   :", sys.version.split()[0])
    sample = encode("mi ve jal to piv.")
    print("sample   :", sample)
    print("If the sample shows boxes, run:  gupt font install" + ("" if is_termux() else " --mono"))
    if shutil.which("fc-list"):
        out = subprocess.run(["fc-list", ":family=Gupt"], capture_output=True, text=True).stdout.strip()
        print("fontconfig:", "Gupt font found" if out else "Gupt font NOT installed")


def build_parser():
    p = argparse.ArgumentParser(prog="gupt", description="Tools for the Gupt secret language.")
    p.add_argument("--version", action="version", version="gupt " + __version__)
    sub = p.add_subparsers(dest="cmd", required=True)

    def io(sp, out=True):
        sp.add_argument("text", nargs="*", help="text (or pipe via stdin)")
        sp.add_argument("-f", "--file", help="read text from a file")
        if out:
            sp.add_argument("-o", "--output", help="write to a file")

    s = sub.add_parser("enc", help="Roman key text -> Gupt glyphs"); io(s)
    s.add_argument("--strict", action="store_true", help="fail on words that are not valid Gupt")
    s.add_argument("--no-subscripts", action="store_true", help="keep chemistry digits as plain digits")
    s.set_defaults(fn=cmd_enc)
    s = sub.add_parser("dec", help="Gupt glyphs -> Roman key text"); io(s); s.set_defaults(fn=cmd_dec)
    s = sub.add_parser("svg", help="render text to an SVG image"); io(s)
    s.add_argument("--scale", type=float, default=4.0); s.add_argument("--color", default="#1d2142")
    s.add_argument("--background"); s.add_argument("--caption", action="store_true", help="add the Roman text below")
    s.set_defaults(fn=cmd_svg)
    s = sub.add_parser("png", help="render text to PNG (needs cairosvg)"); io(s)
    s.add_argument("--scale", type=float, default=4.0); s.add_argument("--color", default="#1d2142")
    s.add_argument("--background"); s.set_defaults(fn=cmd_png)
    s = sub.add_parser("table", help="print the codepoint table (Markdown)"); s.set_defaults(fn=cmd_table)
    s = sub.add_parser("check", help="validate a text file"); s.add_argument("file"); s.set_defaults(fn=cmd_check)
    s = sub.add_parser("repl", help="interactive shell"); s.set_defaults(fn=cmd_repl)
    s = sub.add_parser("font", help="build / patch / install the Gupt font")
    s.add_argument("action", choices=["build", "patch", "install"])
    s.add_argument("-o", "--output"); s.add_argument("--base", help="base monospace .ttf for patch/Termux")
    s.add_argument("--mono", action="store_true", help="(Linux install) also install 'Gupt Mono'")
    s.set_defaults(fn=cmd_font)
    s = sub.add_parser("doctor", help="check your setup"); s.set_defaults(fn=cmd_doctor)
    return p


def main(argv=None):
    try:
        import signal
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    except (ImportError, AttributeError, ValueError):
        pass
    args = build_parser().parse_args(argv)
    try:
        return args.fn(args) or 0
    except GuptError as e:
        print("gupt:", e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
