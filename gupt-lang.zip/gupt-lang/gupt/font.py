"""Build the Gupt font (TrueType) from the shared glyph geometry.

Two products:
  * build_font()  -> standalone "Gupt" font with only Gupt glyphs (PUA), good for
                     desktop apps, web (convert to WOFF2) and fontconfig fallback.
  * patch_font()  -> your existing monospace TrueType font + Gupt glyphs, renamed
                     "Gupt Mono". Needed on Termux, which uses ONE font file.
"""
import math

from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont

from . import shapes
from .core import (BASE_KEYS, CP_ASP, CP_CHEM, CP_CHEMCAP, CP_LONG, CP_PLAIN, CP_STOP)

STROKE = 1.25          # stroke width in glyph units (heavier than print, reads well in terminals)


def _area(pts):
    return sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1])) / 2


def _cw(pts):
    return pts[::-1] if _area(pts) > 0 else pts


def _ccw(pts):
    return pts[::-1] if _area(pts) < 0 else pts


def _circle(cx, cy, r, n=28):
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n)]


def _capsule(p0, p1, w, n=6):
    (x0, y0), (x1, y1) = p0, p1
    r = w / 2
    if (x0, y0) == (x1, y1):
        return _circle(x0, y0, r)
    ang = math.atan2(y1 - y0, x1 - x0)
    pts = []
    for i in range(n + 1):
        a = ang - math.pi / 2 + math.pi * i / n
        pts.append((x1 + r * math.cos(a), y1 + r * math.sin(a)))
    for i in range(n + 1):
        a = ang + math.pi / 2 + math.pi * i / n
        pts.append((x0 + r * math.cos(a), y0 + r * math.sin(a)))
    return pts


def _contours(prims, w):
    """Primitives (glyph units) -> list of closed contours in glyph units."""
    out = []
    for p in prims:
        k = p[0]
        if k == "line":
            out.append(_cw(_capsule((p[1], p[2]), (p[3], p[4]), w)))
        elif k == "ring":
            out.append(_cw(_circle(p[1], p[2], p[3] + w / 2)))
            out.append(_ccw(_circle(p[1], p[2], p[3] - w / 2)))
        elif k == "arc":
            _, cx, cy, r, a0, ext = p
            steps = max(4, int(abs(ext) / 12))
            pts = [(cx + r * math.cos(math.radians(a0 + ext * i / steps)),
                    cy + r * math.sin(math.radians(a0 + ext * i / steps))) for i in range(steps + 1)]
            for a, b in zip(pts, pts[1:]):
                out.append(_cw(_capsule(a, b, w, 4)))
        elif k == "poly":
            pts = p[1]
            for a, b in zip(pts, pts[1:] + pts[:1]):
                out.append(_cw(_capsule(a, b, w, 4)))
        elif k == "dot":
            out.append(_cw(_circle(p[1], p[2], p[3])))
        elif k == "fill":
            out.append(_cw(list(p[1])))
    return out


def _hbar(y, w, adv=shapes.ADVANCE):
    return [(0, y - w / 2), (0, y + w / 2), (adv, y + w / 2), (adv, y - w / 2)]


def glyph_specs():
    """(codepoint, key, asp, long, chem_level) for every glyph in the font."""
    specs = []
    for k in BASE_KEYS:
        specs.append((CP_PLAIN[k], k, False, False, 0))
    for k, cp in CP_LONG.items():
        specs.append((cp, k, False, True, 0))
    for k, cp in CP_ASP.items():
        specs.append((cp, k, True, False, 0))
    for k in BASE_KEYS:
        specs.append((CP_CHEM[k], k, False, False, 1))
        specs.append((CP_CHEMCAP[k], k, False, False, 2))
    return specs


def build_glyphs(upem=1000, advance=600, stroke=STROKE):
    """Return {name: (glyph, advance, lsb, codepoint)} for all Gupt glyphs."""
    S = advance / shapes.ADVANCE
    w = stroke
    glyphs = {}
    items = []
    for cp, key, asp, lng, chem in glyph_specs():
        prims = shapes.glyph_shapes(key, asp=asp, long=lng, flag=(chem == 2))
        cont = _contours(prims, w)
        cont.append(_cw(_hbar(shapes.HEADLINE, 0.9)))
        if chem:
            cont.append(_cw(_hbar(shapes.HEADLINE2, 0.9)))
        items.append((cp, cont))
    items.append((CP_STOP, _contours(shapes.sentence_dot(), w)))
    for cp, cont in items:
        pen = TTGlyphPen(None)
        xs = []
        for c in cont:
            pts = [(round(x * S), round(y * S)) for x, y in c]
            xs += [p[0] for p in pts]
            pen.moveTo(pts[0])
            for q in pts[1:]:
                pen.lineTo(q)
            pen.closePath()
        g = pen.glyph()
        glyphs["uni%04X" % cp] = (g, advance, min(xs), cp)
    return glyphs


def _notdef(advance, upem):
    pen = TTGlyphPen(None)
    m, t = int(advance * 0.1), int(upem * 0.7)
    pen.moveTo((m, 0)); pen.lineTo((m, t)); pen.lineTo((advance - m, t)); pen.lineTo((advance - m, 0)); pen.closePath()
    i = int(advance * 0.2)
    pen.moveTo((m + i, i)); pen.lineTo((advance - m - i, i)); pen.lineTo((advance - m - i, t - i)); pen.lineTo((m + i, t - i)); pen.closePath()
    return pen.glyph()


def build_font(path, family="Gupt", upem=1000, advance=600):
    """Write a standalone Gupt TrueType font to `path`."""
    glyphs = build_glyphs(upem, advance)
    empty = TTGlyphPen(None).glyph()
    order = [".notdef", "space"] + sorted(glyphs)
    glyf = {".notdef": _notdef(advance, upem), "space": empty}
    metrics = {".notdef": (advance, int(advance * 0.1)), "space": (advance, 0)}
    cmap = {0x20: "space"}
    for name, (g, adv, lsb, cp) in glyphs.items():
        glyf[name] = g
        metrics[name] = (adv, lsb)
        cmap[cp] = name
    fb = FontBuilder(upem, isTTF=True)
    fb.setupGlyphOrder(order)
    fb.setupCharacterMap(cmap)
    fb.setupGlyf(glyf)
    fb.setupHorizontalMetrics(metrics)
    fb.setupHorizontalHeader(ascent=int(upem * 1.0), descent=-int(upem * 0.2))
    fb.setupNameTable({"familyName": family, "styleName": "Regular",
                       "uniqueFontIdentifier": family + " Regular 0.1.0",
                       "fullName": family + " Regular", "psName": family + "-Regular",
                       "version": "Version 0.1.0",
                       "licenseDescription": "MIT License"})
    fb.setupOS2(sTypoAscender=upem, sTypoDescender=-int(upem * 0.2), usWinAscent=upem,
                usWinDescent=int(upem * 0.2), sxHeight=int(upem * 0.5), sCapHeight=int(upem * 0.7))
    fb.setupPost(isFixedPitch=1)
    fb.save(path)
    return path


def patch_font(base_path, out_path, family="Gupt Mono"):
    """Add the Gupt glyphs to an existing monospace TrueType font."""
    font = TTFont(base_path)
    if "glyf" not in font:
        raise ValueError("base font must be TrueType (glyf outlines), not CFF/OTF")
    upem = font["head"].unitsPerEm
    hmtx = font["hmtx"].metrics
    ref = next((n for n in ("M", "zero", "a") if n in hmtx), None)
    if ref is None:
        raise ValueError("base font has no M/zero/a glyph to measure the cell width")
    advance = hmtx[ref][0]
    glyphs = build_glyphs(upem, advance)
    order = list(font.getGlyphOrder())
    for name, (g, adv, lsb, cp) in glyphs.items():
        if name in order:
            continue
        order.append(name)
        font["glyf"].glyphs[name] = g
        hmtx[name] = (adv, lsb)
        for t in font["cmap"].tables:
            if t.isUnicode() and (t.format in (4, 12, 13) or hasattr(t, "cmap")):
                t.cmap[cp] = name
    font.setGlyphOrder(order)
    font["glyf"].glyphOrder = order
    for tag in ("hdmx", "LTSH", "VDMX"):
        if tag in font:
            del font[tag]
    for rec in font["name"].names:
        if rec.nameID in (1, 16):
            rec.string = family
        elif rec.nameID in (3, 4):
            rec.string = family + " Regular"
        elif rec.nameID == 6:
            rec.string = family.replace(" ", "") + "-Regular"
        elif rec.nameID == 2 or rec.nameID == 17:
            rec.string = "Regular"
    font.save(out_path)
    return out_path
