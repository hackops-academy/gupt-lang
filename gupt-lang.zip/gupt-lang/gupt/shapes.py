"""Vector geometry of every Gupt glyph, shared by the SVG renderer and the font builder.

Units: the glyph cell is 9.0 wide. y = 0 is the bottom of the box, the headline sits at
y = 11.6. Primitives:
    ("line", x1, y1, x2, y2)       stroked segment
    ("ring", cx, cy, r)            stroked circle
    ("arc", cx, cy, r, a0, ext)    stroked arc, degrees, counter-clockwise
    ("poly", [(x, y), ...])        stroked closed polygon
    ("dot", cx, cy, r)             filled circle
    ("fill", [(x, y), ...])        filled polygon
"""
from .core import SPEC, VOWELS

ADVANCE = 9.0
HEADLINE = 11.6
HEADLINE2 = 12.4
DX = 0.5

_FAM = {
    "lip": dict(dot=(4, 5.2), bar=(0.8, 5.2, 7.2, 5.2), bardot=(4, 7.0), two=((4, 6.6), (4, 3.8))),
    "tee": dict(dot=(4, 4.0), bar=(1.46, 3.2, 6.54, 3.2), bardot=(4, 5.3), two=((4, 5.2), (4, 3.0))),
    "ret": dict(dot=(4, 6.2)),
    "pal": dict(dot=(4, 4.0), bar=(1, 3.6, 7, 3.6), bardot=(4, 6.0), two=((4, 3.6), (4, 6.0))),
    "thr": dict(dot=(6.4, 5.2), bar=(2, 5.2, 6, 5.2)),
}


def glyph_shapes(key, asp=False, long=False, flag=False):
    """Primitives for one glyph, already shifted to sit centred in the 9.0 cell."""
    out = []

    def line(a, b, c, d):
        out.append(("line", a + DX, b, c + DX, d))

    def ring(cx, cy, r):
        out.append(("ring", cx + DX, cy, r))

    def dot(cx, cy, r=0.85):
        out.append(("dot", cx + DX, cy, r))

    def arc(cx, cy, r, a0, ext):
        out.append(("arc", cx + DX, cy, r, a0, ext))

    def poly(pts):
        out.append(("poly", [(x + DX, y) for x, y in pts]))

    if key in VOWELS:
        if key == "a":
            dot(4, 4.8, 1.2)
        elif key == "e":
            line(1.9, 4.8, 6.1, 4.8)
        elif key == "i":
            line(4, 2.6, 4, 7.0)
        elif key == "o":
            ring(4, 4.8, 1.9)
        elif key == "u":
            arc(4, 5.9, 2.2, 180, 180)
        if long:
            line(2.2, 1.4, 5.8, 1.4)
    else:
        fam, man = SPEC[key]
        F = _FAM[fam]
        if fam == "lip":
            ring(4, 5.2, 3.2)
        elif fam == "tee":
            poly([(4, 8.6), (0.8, 1.8), (7.2, 1.8)])
        elif fam == "ret":
            poly([(0.8, 8.6), (7.2, 8.6), (4, 1.8)])
        elif fam == "pal":
            line(1, 1.8, 1, 5.6)
            arc(4, 5.6, 3, 0, 180)
            line(7, 5.6, 7, 1.8)
        else:
            line(4, 1.8, 4, 8.6)
        if man == "voiced":
            dot(*F["dot"])
        elif man == "nasal":
            line(2.3, 0.5, 5.7, 0.5)
        elif man == "hiss":
            line(*F["bar"])
        elif man == "buzz":
            line(*F["bar"])
            dot(*F["bardot"], 0.7)
        elif man == "glide":
            for q in F["two"]:
                dot(*q, 0.65)
        elif man == "trill":
            poly_open = [(2.0, 3.0), (3.0, 4.2), (4.0, 3.0), (5.0, 4.2), (6.0, 3.0)]
            for a, b in zip(poly_open, poly_open[1:]):
                line(a[0], a[1], b[0], b[1])
        if asp:
            ring(7.5, 9.9, 0.55)
    if flag:
        out.append(("fill", [(2.9 + DX, 14.1), (5.1 + DX, 14.1), (4 + DX, 12.9)]))
    return out


def sentence_dot():
    return [("dot", 2.2, 1.3, 0.9)]
