"""Gupt: a constructed secret language with its own script, grammar and tools."""

from .core import (  # noqa: F401
    GuptError, SPEC, encode, decode, encode_chem, decode_chem, parse_word, codepoint_table,
)

__version__ = "0.1.0"
