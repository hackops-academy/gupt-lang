"""Render Gupt text to SVG (pure Python, no dependencies)."""
from xml.sax.saxutils import escape

from .core import (_REV, CP_STOP, STOP, GuptError, UNSUB, encode)
from .shapes import ADVANCE, HEADLINE, HEADLINE2, glyph_shapes, sentence_dot

LINE_H = 17.0


def _glyph_svg(prims, x0, y0, s, w, color):
    """Return SVG elements for prims placed at x0,y0 (top-left origin, y down)."""
    def X(x):
        return x0 + x * s

    def Y(y):
        return y0 + (14.6 - y) * s
    out = []
    style = 'fill="none" stroke="%s" stroke-width="%.2f" stroke-linecap="round" stroke-linejoin="round"' % (color, w * s)
    for p in prims:
        k = p[0]
        if k == "line":
            out.append('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" %s/>' % (X(p[1]), Y(p[2]), X(p[3]), Y(p[4]), style))
        elif k == "ring":
            out.append('<circle cx="%.2f" cy="%.2f" r="%.2f" %s/>' % (X(p[1]), Y(p[2]), p[3] * s, style))
        elif k == "arc":
            import math
            _, cx, cy, r, a0, ext = p
            a1 = math.radians(a0)
            a2 = math.radians(a0 + ext)
            x1, y1 = X(cx + r * math.cos(a1)), Y(cy + r * math.sin(a1))
            x2, y2 = X(cx + r * math.cos(a2)), Y(cy + r * math.sin(a2))
            out.append('<path d="M%.2f %.2fA%.2f %.2f 0 %d 0 %.2f %.2f" %s/>' % (
                x1, y1, r * s, r * s, 1 if ext > 180 else 0, x2, y2, style))
        elif k == "poly":
            pts = " ".join("%.2f,%.2f" % (X(a), Y(b)) for a, b in p[1])
            out.append('<polygon points="%s" %s/>' % (pts, style))
        elif k == "dot":
            out.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="%s"/>' % (X(p[1]), Y(p[2]), p[3] * s, color))
        elif k == "fill":
            pts = " ".join("%.2f,%.2f" % (X(a), Y(b)) for a, b in p[1])
            out.append('<polygon points="%s" fill="%s"/>' % (pts, color))
    return out


def to_svg(text, scale=4.0, color="#1d2142", background=None, stroke=0.55, pad=3.0, caption=None):
    """Roman key text (or an already encoded Gupt string) -> SVG document string."""
    if not any(ch in _REV or ord(ch) == CP_STOP for ch in text):
        text = encode(text)
    lines = text.split("\n")
    width = max(sum(ADVANCE if (ch in _REV or ch == STOP) else ADVANCE * 0.62 for ch in ln) for ln in lines)
    W = (width + 2 * pad) * scale
    rows = len(lines) + (1 if caption else 0)
    H = (rows * LINE_H + 2 * pad) * scale
    out = ['<svg xmlns="http://www.w3.org/2000/svg" width="%.0f" height="%.0f" viewBox="0 0 %.2f %.2f">' % (W, H, W, H)]
    if background:
        out.append('<rect width="100%%" height="100%%" fill="%s"/>' % background)
    for li, ln in enumerate(lines):
        x = pad * scale
        y0 = (pad + li * LINE_H) * scale
        run = None
        runs = []
        for ch in ln:
            if ch in _REV or ch == STOP:
                if ch == STOP:
                    prims, chem = sentence_dot(), False
                    if run:
                        runs.append(run)
                        run = None
                else:
                    k, kind = _REV[ch]
                    prims = glyph_shapes(k, asp=kind == "asp", long=kind == "long", flag=kind == "chemcap")
                    chem = kind in ("chem", "chemcap")
                    if run is None:
                        run = [x, x, chem]
                    run[1] = x + ADVANCE * scale
                out += _glyph_svg(prims, x, y0, scale, stroke, color)
                x += ADVANCE * scale
            else:
                if run:
                    runs.append(run)
                    run = None
                if not ch.isspace():
                    out.append('<text x="%.2f" y="%.2f" font-family="monospace" font-size="%.1f" fill="%s">%s</text>' % (
                        x, y0 + (14.6 - 3) * scale, 8 * scale, color, escape(ch.translate(UNSUB))))
                x += ADVANCE * 0.62 * scale
        if run:
            runs.append(run)
        for a, b, chem in runs:
            for hl in ([HEADLINE] + ([HEADLINE2] if chem else [])):
                yy = y0 + (14.6 - hl) * scale
                out.append('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="%s" stroke-width="%.2f" stroke-linecap="round"/>' % (
                    a + 0.4 * scale, yy, b - 0.4 * scale, yy, color, 0.45 * scale))
    if caption:
        out.append('<text x="%.2f" y="%.2f" font-family="monospace" font-size="%.1f" fill="#6b7194">%s</text>' % (
            pad * scale, (pad + len(lines) * LINE_H + 8) * scale, 5.5 * scale, escape(caption)))
    out.append("</svg>")
    return "\n".join(out)
