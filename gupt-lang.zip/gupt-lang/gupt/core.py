"""Core of Gupt: the alphabet, the Roman key parser and Unicode (Private Use Area) mapping.

Every Gupt glyph lives in the Unicode Private Use Area (U+E000..U+F8FF):

    U+E000..U+E01D  30 base glyphs (5 vowels + 25 consonants)
    U+E020..U+E024  long vowels (aa ee ii oo uu)
    U+E030..U+E039  aspirated (ring) consonants: ph bh th dh Th Dh ch jh kh gh
    U+E050          sentence-end dot
    U+E100..U+E11D  chemistry letters (double headline)
    U+E140..U+E15D  chemistry capital letters (double headline + flag)
"""
import re

VOWELS = "aeiou"

# consonant -> (family, manner)
SPEC = {
    "p": ("lip", "plain"), "b": ("lip", "voiced"), "m": ("lip", "nasal"),
    "f": ("lip", "hiss"), "v": ("lip", "buzz"), "w": ("lip", "glide"),
    "t": ("tee", "plain"), "d": ("tee", "voiced"), "n": ("tee", "nasal"),
    "s": ("tee", "hiss"), "z": ("tee", "buzz"), "l": ("tee", "glide"), "r": ("tee", "trill"),
    "T": ("ret", "plain"), "D": ("ret", "voiced"), "N": ("ret", "nasal"),
    "c": ("pal", "plain"), "j": ("pal", "voiced"), "\u00f1": ("pal", "nasal"),
    "x": ("pal", "hiss"), "y": ("pal", "glide"),
    "k": ("thr", "plain"), "g": ("thr", "voiced"), "G": ("thr", "nasal"), "h": ("thr", "hiss"),
}
ASPIRABLE = "pbtdTDcjkg"
BASE_KEYS = list(VOWELS) + list(SPEC)

CP_PLAIN = {k: 0xE000 + i for i, k in enumerate(BASE_KEYS)}
CP_LONG = {v: 0xE020 + i for i, v in enumerate(VOWELS)}
CP_ASP = {k: 0xE030 + i for i, k in enumerate(ASPIRABLE)}
CP_STOP = 0xE050
CP_CHEM = {k: 0xE100 + i for i, k in enumerate(BASE_KEYS)}
CP_CHEMCAP = {k: 0xE140 + i for i, k in enumerate(BASE_KEYS)}

_REV = {}
for _k, _cp in CP_PLAIN.items():
    _REV[chr(_cp)] = (_k, "plain")
for _k, _cp in CP_LONG.items():
    _REV[chr(_cp)] = (_k, "long")
for _k, _cp in CP_ASP.items():
    _REV[chr(_cp)] = (_k, "asp")
for _k, _cp in CP_CHEM.items():
    _REV[chr(_cp)] = (_k, "chem")
for _k, _cp in CP_CHEMCAP.items():
    _REV[chr(_cp)] = (_k, "chemcap")
STOP = chr(CP_STOP)

SUB = str.maketrans("0123456789", "\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087\u2088\u2089")
UNSUB = str.maketrans("\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087\u2088\u2089", "0123456789")


class GuptError(ValueError):
    """Raised when text cannot be written in Gupt."""


def parse_word(word):
    """Roman key -> list of (key, kind) tokens, kind in plain/long/asp.

    Rules: 'sh' is one glyph (x); doubled vowel = long; p b t d T D c j k g followed
    by 'h' = breath ring. A hyphen blocks the digraph rules (k-h = k then h).
    """
    toks, i = [], 0
    while i < len(word):
        ch = word[i]
        nxt = word[i + 1] if i + 1 < len(word) else ""
        if ch == "-":
            i += 1
        elif ch == "s" and nxt == "h":
            toks.append(("x", "plain"))
            i += 2
        elif ch in VOWELS:
            if nxt == ch:
                toks.append((ch, "long"))
                i += 2
            else:
                toks.append((ch, "plain"))
                i += 1
        elif ch in ASPIRABLE and nxt == "h":
            toks.append((ch, "asp"))
            i += 2
        elif ch in SPEC:
            toks.append((ch, "plain"))
            i += 1
        else:
            raise GuptError("cannot write %r in %r" % (ch, word))
    return toks


def _cp(key, kind):
    return chr({"plain": CP_PLAIN, "long": CP_LONG, "asp": CP_ASP}[kind][key])


def encode_word(word):
    return "".join(_cp(k, kind) for k, kind in parse_word(word))


_CHUNK = re.compile(r"(\[\[.+?\]\])|(\s+)|([^\s\[]+|\[)")


def encode(text, strict=False, subscripts=True):
    """Roman key text -> Gupt string in the Private Use Area.

    Words that are not valid Gupt (numbers, URLs, ...) are left untouched unless
    strict=True. Chemistry goes in double brackets: [[H2SO4]].
    """
    out = []
    for m in _CHUNK.finditer(text):
        chem, space, word = m.groups()
        if chem:
            out.append(encode_chem(chem[2:-2], subscripts))
        elif space:
            out.append(space)
        else:
            tail = ""
            while word and word[-1] in ".":
                tail += STOP
                word = word[:-1]
            if word:
                try:
                    out.append(encode_word(word))
                except GuptError:
                    if strict:
                        raise
                    out.append(word)
            out.append(tail)
    return "".join(out)


def _chem_letter(l):
    l = l.lower()
    return {"x": "ks", "q": "k"}.get(l, l)


def encode_chem(formula, subscripts=True):
    """Chemistry mode: each symbol letter becomes a glyph, capitals get the flag."""
    formula = formula.replace("->", "\u2192")
    out, i, prev = [], 0, None
    while i < len(formula):
        ch = formula[i]
        if ch.isdigit():
            j = i
            while j < len(formula) and formula[j].isdigit():
                j += 1
            num = formula[i:j]
            out.append(num.translate(SUB) if subscripts and prev in ("el", "close") else num)
            prev, i = "dig", j
        elif ch.isalpha() and ch.isupper():
            sym = ch + (formula[i + 1] if i + 1 < len(formula) and formula[i + 1].islower() else "")
            first = True
            for letter in sym:
                for k in _chem_letter(letter):
                    if k not in CP_CHEM:
                        raise GuptError("no glyph for chemistry letter %r" % letter)
                    out.append(chr((CP_CHEMCAP if first else CP_CHEM)[k]))
                    first = False
            prev, i = "el", i + len(sym)
        else:
            out.append(ch)
            prev = "close" if ch in ")]" else "other"
            i += 1
    return "".join(out)


def decode(text):
    """Gupt string -> Roman key text (chemistry glyphs become Latin letters)."""
    out = []
    for ch in text:
        if ch == STOP:
            out.append(".")
        elif ch in _REV:
            k, kind = _REV[ch]
            if kind == "long":
                out.append(k * 2)
            elif kind == "asp":
                out.append(k + "h")
            elif kind == "chem":
                out.append(k)
            elif kind == "chemcap":
                out.append(k.upper())
            else:
                out.append("sh" if k == "x" else k)
        else:
            out.append(ch.translate(UNSUB))
    return "".join(out)


def decode_chem(text):
    return decode(text)


def codepoint_table():
    """Rows (codepoint, roman key, description) for docs and the CLI."""
    rows = []
    for k in BASE_KEYS:
        fam, man = SPEC.get(k, ("vowel", "plain"))
        rows.append((CP_PLAIN[k], "sh" if k == "x" else k, "%s %s" % (fam, man)))
    for k, cp in CP_LONG.items():
        rows.append((cp, k * 2, "long vowel"))
    for k, cp in CP_ASP.items():
        rows.append((cp, k + "h", "breath ring"))
    rows.append((CP_STOP, ".", "sentence dot"))
    return rows
