import os

import pytest

from gupt import GuptError, decode, encode, encode_chem, parse_word
from gupt.core import CP_ASP, CP_CHEM, CP_CHEMCAP, CP_LONG, CP_PLAIN, CP_STOP


def test_codepoints_unique_and_private_use():
    cps = [*CP_PLAIN.values(), *CP_LONG.values(), *CP_ASP.values(), CP_STOP, *CP_CHEM.values(), *CP_CHEMCAP.values()]
    assert len(cps) == len(set(cps))
    assert all(0xE000 <= c <= 0xF8FF for c in cps)


def test_thirty_base_glyphs():
    assert len(CP_PLAIN) == 30


@pytest.mark.parametrize("word", ["mi", "jal", "kitab", "khaana", "choTa", "dhanyavad", "roTi", "paani", "caay", "ship".replace("ship", "ship")])
def test_roundtrip_words(word):
    assert decode(encode(word, strict=True)) == word


def test_rules():
    assert parse_word("sha") == [("x", "plain"), ("a", "plain")]
    assert parse_word("khaa") == [("k", "asp"), ("a", "long")]
    assert parse_word("ch") == [("c", "asp")]
    assert parse_word("k-h") == [("k", "plain"), ("h", "plain")]
    assert len(parse_word("kha-ak")) == 4


def test_suffix_hyphen_is_dropped_but_kept_in_pieces():
    assert decode(encode("piv-ak")) == "pivak"


def test_sentence_dot():
    assert encode("jal.").endswith(chr(CP_STOP))
    assert decode(encode("jal.")) == "jal."


def test_strict_and_lenient():
    with pytest.raises(GuptError):
        encode("zq", strict=True)
    assert encode("2024 q") == "2024 q"


def test_chemistry_flags():
    assert encode_chem("Co") != encode_chem("CO")
    co, c_o = encode_chem("Co"), encode_chem("CO")
    assert co[0] == c_o[0] and ord(co[1]) in CP_CHEM.values() and ord(c_o[1]) in CP_CHEMCAP.values()


def test_chemistry_digits_and_arrow():
    assert encode_chem("H2O").endswith(chr(CP_CHEMCAP["o"]))
    assert "\u2082" in encode_chem("H2O")
    assert decode(encode_chem("2H2 + O2 -> 2H2O")) == "2H2 + O2 \u2192 2H2O"


def test_inline_chem_in_sentence():
    out = encode("jal ve [[H2O]].")
    assert decode(out) == "jal ve H2O."


def test_svg():
    from gupt.render import to_svg
    svg = to_svg("mi ve jal. [[H2O]]")
    assert svg.startswith("<svg") and svg.endswith("</svg>") and "<circle" in svg


def test_font_has_every_glyph(tmp_path):
    from fontTools.ttLib import TTFont
    from gupt.font import build_font
    path = build_font(str(tmp_path / "g.ttf"))
    cmap = TTFont(path).getBestCmap()
    for cp in [*CP_PLAIN.values(), *CP_LONG.values(), *CP_ASP.values(), CP_STOP, *CP_CHEM.values(), *CP_CHEMCAP.values()]:
        assert cp in cmap


@pytest.mark.skipif(not os.path.exists("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"), reason="no DejaVu Sans Mono")
def test_patch_mono(tmp_path):
    from fontTools.ttLib import TTFont
    from gupt.font import patch_font
    out = patch_font("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", str(tmp_path / "m.ttf"))
    cmap = TTFont(out).getBestCmap()
    assert CP_PLAIN["a"] in cmap and ord("A") in cmap
