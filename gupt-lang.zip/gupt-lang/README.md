# Gupt

A constructed secret language with its **own script**, its own grammar, and tools to use it on
**Kali Linux**, **Termux** and anywhere Python runs. It can write Hindi, Hinglish, English (by
sound) and chemistry formulas.

```
gupt enc "mi ve jal to piv-ak."      # I drank water.
gupt enc "jal ve [[H2SO4]]."         # chemistry mode
gupt svg "mi ve jal to piv." -o x.svg
```

> **Not encryption.** Gupt hides text from people who cannot read the script. It does not
> protect secrets from anyone who has this repo. Use real crypto (age, GPG) for confidentiality.

## Install

### Kali Linux / Debian / Ubuntu
```bash
sudo apt install python3-pip git fontconfig
git clone https://github.com/<you>/gupt-lang && cd gupt-lang
pip install . --break-system-packages      # or: pipx install .
gupt font install --mono                   # installs the font(s) and refreshes the cache
gupt doctor
```
Restart the terminal. If your terminal font is a normal monospace font, Gupt glyphs appear through
font fallback. For the most even spacing, set the terminal font to **Gupt Mono**.

### Termux (Android)
```bash
pkg install python git
git clone https://github.com/<you>/gupt-lang && cd gupt-lang
pip install .
gupt font install        # patches your system mono font, writes ~/.termux/font.ttf, reloads
```
Termux uses a single font file, so `font install` builds **Gupt Mono**: the Android monospace
font plus the Gupt glyphs (your old font is backed up to `~/.termux/font.ttf.bak`). Use
`--base /path/to/Font.ttf` to start from another TrueType monospace font.

## Commands

| Command | What it does |
|---|---|
| `gupt enc TEXT` | Roman key to Gupt glyphs (pipe or `-f file` also work) |
| `gupt dec TEXT` | Gupt glyphs back to Roman key |
| `gupt repl` | interactive shell |
| `gupt svg TEXT -o out.svg` | render an image (`--caption`, `--color`, `--background`) |
| `gupt png TEXT -o out.png` | PNG (install `gupt-lang[png]`) |
| `gupt check FILE` | validate that a file is valid Gupt |
| `gupt table` | print the codepoint table |
| `gupt font build\|patch\|install` | build the font, patch a mono font, or install it |
| `gupt doctor` | check your setup |

Use as a library:
```python
from gupt import encode, decode
print(encode("mi ve jal to piv-ak."))
```

## How it works
Every glyph is a Unicode **Private Use Area** code point (U+E000 and up), so Gupt text is ordinary
UTF-8 that you can store in files, git, ssh sessions and clipboards. A font draws the glyphs;
`gupt/shapes.py` holds the single vector definition used by both the SVG renderer and the font
builder. Anyone without the font sees empty boxes.

See [docs/SPEC.md](docs/SPEC.md), [docs/CODEPOINTS.md](docs/CODEPOINTS.md) and the
[learning book](docs/Gupt_Learning_Book.pdf).

## Project layout
```
gupt/        core (parser, encoder), shapes, font builder, SVG renderer, CLI
fonts/       prebuilt Gupt-Regular.ttf (glyphs only)
docs/        spec, codepoints, keyboard roadmap, learning book PDF
book/        generator for the PDF book
tests/       pytest suite
```

## Contributing
Issues and PRs welcome: new vocabulary, keyboards (Keyman, XKB), a WOFF2 build, glyph polish.
Run `pip install -e ".[dev]" && pytest`.

## License
MIT. The prebuilt font and glyph designs are MIT as well. Patched fonts you build locally stay under
the license of the base font you used (for example DejaVu), so do not redistribute them without
checking that license.
